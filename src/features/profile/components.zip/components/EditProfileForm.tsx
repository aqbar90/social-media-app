'use client';

import { useEffect, useMemo, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

import { updateProfileSchema } from '../schemas/update-profile.schema';
import type { UpdateProfileFormValues } from '../schemas/update-profile.schema';
import type { User } from '@/types/entities/user';

import AvatarUpload from './AvatarUpload';
import BioField from './BioField';
import EditProfileHeader from './EditProfileHeader';
import EmailField from './EmailField';
import NameField from './NameField';
import PhoneField from './PhoneField';
import ProfileField from './ProfileField';
import SaveChangesButton from './SaveChangesButton';
import UsernameField from './UsernameField';

interface EditProfileFormProps {
  user: User;
  onSubmit: (values: UpdateProfileFormValues) => void | Promise<void>;
  isSubmitting?: boolean;
}

export default function EditProfileForm({
  user,
  onSubmit,
  isSubmitting = false,
}: EditProfileFormProps) {
  const {
    register,
    control,
    handleSubmit,
    watch,
    reset,
    formState: { errors, isDirty },
  } = useForm<UpdateProfileFormValues>({
    resolver: zodResolver(updateProfileSchema),
    defaultValues: {
      name: user.name,
      username: user.username,
      email: user.email,
      phone: user.phone ?? '',
      bio: user.bio ?? '',
      avatar: undefined,
    },
    mode: 'onBlur',
  });

  useEffect(() => {
    reset({
      name: user.name,
      username: user.username,
      email: user.email,
      phone: user.phone ?? '',
      bio: user.bio ?? '',
      avatar: undefined,
    });
  }, [reset, user]);

  const avatar = watch('avatar');

  const avatarFile = useMemo(() => {
    if (avatar instanceof File) {
      return avatar;
    }

    if (avatar instanceof FileList && avatar.length > 0) {
      return avatar.item(0) ?? undefined;
    }

    return undefined;
  }, [avatar]);

  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!avatarFile) {
      setPreviewUrl(null);
      return;
    }

    const objectUrl = URL.createObjectURL(avatarFile);

    setPreviewUrl(objectUrl);

    return () => {
      URL.revokeObjectURL(objectUrl);
    };
  }, [avatarFile]);

  const avatarSrc = previewUrl ?? user.avatarUrl ?? '';

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className='flex w-full flex-col gap-6'
      noValidate
    >
      <EditProfileHeader />

      <Controller
        name='avatar'
        control={control}
        render={({ field: { onChange, ref } }) => (
          <AvatarUpload
            ref={ref}
            imageUrl={avatarSrc}
            error={errors.avatar?.message}
            onFileChange={(file) => {
              onChange(file);
            }}
          />
        )}
      />

      <ProfileField label='Name' error={errors.name?.message}>
        <NameField {...register('name')} autoComplete='name' />
      </ProfileField>

      <ProfileField label='Username' error={errors.username?.message}>
        <UsernameField {...register('username')} autoComplete='username' />
      </ProfileField>

      <ProfileField label='Email' error={errors.email?.message}>
        <EmailField {...register('email')} autoComplete='email' />
      </ProfileField>

      <ProfileField label='Phone Number' error={errors.phone?.message}>
        <PhoneField {...register('phone')} autoComplete='tel' />
      </ProfileField>

      <ProfileField label='Bio' error={errors.bio?.message}>
        <BioField {...register('bio')} rows={5} />
      </ProfileField>

      <SaveChangesButton
        type='submit'
        disabled={!isDirty || isSubmitting}
        loading={isSubmitting}
      />
    </form>
  );
}
